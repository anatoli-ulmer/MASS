//////////////////////////////////////////////////////////////////////////////////////////
//
//  LinuxConfigPCI.c	Implementation of Configuration for PCI9080-based Acqiris Devices
//
//----------------------------------------------------------------------------------------
//  Copyright 2000 Acqiris. All rights reserved.
//
//  Started:	 6 JUN 2000
//		26/06/01 esch: set PCI bus master, needed for HP 
//
//  Owned by:	V. Hungerbuhler
//
//////////////////////////////////////////////////////////////////////////////////////////
#include <linux/kernel.h>
#include <linux/delay.h>
#include <linux/fs.h>
#include <linux/slab.h>
#include <linux/pci.h>
#include <asm/io.h>

#include "DDrIORules.h"
#include "LinuxDriverPCI.h"

extern long dbgl;

ULONG AcqrsKMoFindDevices(AcqrsKMoDevExtension* dxP, char* vendorStringP);

//////////////////////////////////////////////////////////////////////////////////////////
ULONG AcqrsKMoConfOps(ULONG cmd, DDrLinuxIO* ioBlkP)
{
	ULONG	code	= cmd;
	ULONG	device	= (code >> 16) - DEV_TYPE;
	ULONG*	cmdP	= ioBlkP->inBufferP;
	ULONG*	outP	= ioBlkP->outBufferP;
	ULONG	outSize	= ioBlkP->nOutBufferSize;
	ULONG*	NreturnP= ioBlkP->bytesReturnedP;

	if (outP == NULL)					// non-existing outBuf ==> size is zero!
		outSize = 0;

	*NreturnP = 0;						// default value
	code -= (device << 16);				// eliminate device # from code	

	switch (code)
	{
	case IOCTL_FIND_DEVICES:				// Find devices and their resources in Registry
	// NOTE: this method assumes that the input buffer (cmdP) contains an 8-character
	//		 vendorID string which must be contained in the registry entry. Devices which
	//		 do not contain this string are considered of no interest.
	  {
		ULONG buffer_size;

		if (outSize < 4)
			return ERROR_BUFFER_OVERFLOW;

	// Try to find the number of devices (without any resource initialization)
		if (AcqrsKMoFindDevices(NULL, (char*) cmdP ) != ERROR_SUCCESS)
			return ERROR_PATH_NOT_FOUND;

	// Return # devices to the calling routine
		*outP = AcqrsKMoNbrDevices;
		*NreturnP = 4;

	// Didn't find any devices, there is no point in allocating space
		if (AcqrsKMoNbrDevices <= 0)
			return ERROR_SUCCESS;

	// Allocate permanent space in Control Block for device resources
		buffer_size = AcqrsKMoNbrDevices * sizeof(AcqrsKMoDevExtension);
		AcqrsKMoDevExtensionBase = (ULONG) kmalloc(buffer_size, GFP_KERNEL);
		if (AcqrsKMoDevExtensionBase == 0)
			return ERROR_NOT_ENOUGH_MEMORY;

	// Initialize the resource parameters of all devices
//		printk("Acqiris:   1  DEB  %08x \n",AcqrsKMoDevExtensionBase);
		AcqrsKMoFindDevices((AcqrsKMoDevExtension*) AcqrsKMoDevExtensionBase, (char*) cmdP);
  //    kfree(AcqrsKMoDevExtensionBase);
	  }
		break;

	case IOCTL_GET_NUMBER_DEVICES:			// Return number of devices
	  {
		if (outSize < 4)
			return ERROR_BUFFER_OVERFLOW;
		*outP = AcqrsKMoNbrDevices;
		*NreturnP = 4;	
		break;
	  }

	case IOCTL_GET_RESOURCES:				// Report (already stored) device resources
	  {
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);

		if ( (AcqrsKMoNbrDevices == 0) || (device >= AcqrsKMoNbrDevices) )
			return ERROR_INVALID_PARAMETER;
		if (outSize < sizeof(DDrResources) )
			return ERROR_BUFFER_OVERFLOW;

	// Copy the resource block to the output
		*((DDrResources*) outP) = dxP->res;
		*NreturnP = sizeof(DDrResources);
	  }
		break;

	case IOCTL_GET_VERSION:					// Report device driver version #

		if (outSize < 4)
			return ERROR_BUFFER_OVERFLOW;
		*outP = (ULONG)LNX_VERSION;
		*NreturnP = 4;	
		break;

	case IOCTL_RESTORE_BARS:
	  {
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);
		int result;
		ULONG vendorID, deviceID = 0;
		
		struct pci_dev *devP = NULL;
		//devP = pci_find_slot(dxP->res.busNumber, dxP->devfn);
		vendorID = 0x14ec;
		while (  (devP = pci_find_device(vendorID, deviceID, devP))  )
		{
			if (devP->bus->number == dxP->res.busNumber && devP->devfn == dxP->devfn)
				break;
		}
		
		if (devP == NULL)
			return ERROR_INVALID_HANDLE;
		
		result = pci_write_config_dword(devP, PCI_BASE_ADDRESS_0, pci_resource_start(devP, 0));
		if(dbgl&DINIT) printk("Acqiris: BAR0: (%d) %08lx, %08lx\n", result, pci_resource_start(devP, 0), dxP->res.controlAddr);
		
		if( (pci_resource_flags (devP, 1) & IORESOURCE_IO) && (pci_resource_flags (devP, 2) & IORESOURCE_MEM) )
	  	{
			result = pci_write_config_dword(devP, PCI_BASE_ADDRESS_2, pci_resource_start(devP, 2));
			if(dbgl&DINIT) printk("Acqiris: BAR1: (%d) %08lx, %08lx\n", result, pci_resource_start(devP, 2), dxP->res.directAddr);
		}
		else
		{
			result = pci_write_config_dword(devP, PCI_BASE_ADDRESS_1, pci_resource_start(devP, 1));
			if(dbgl&DINIT) printk("Acqiris: BAR1: (%d) %08lx, %08lx\n", result, pci_resource_start(devP, 1), dxP->res.directAddr);
		}
		
		result = pci_write_config_byte(devP, PCI_COMMAND, 0x07);
		if(dbgl&DINIT) printk("Acqiris: CMDR: (%d)\n", result);
		
		result = pci_write_config_byte(devP, PCI_INTERRUPT_LINE, devP->irq);
		if(dbgl&DINIT) printk("Acqiris: INTR: (%d) %u, %ld\n", result, devP->irq, dxP->res.interrupt);
		
		
	  }
	  break;
	  
	default:								// Unrecognized IOCTL --> Error
		return ERROR_NOT_SUPPORTED;
	}
    return ERROR_SUCCESS;
}

//////////////////////////////////////////////////////////////////////////////////////////
ULONG AcqrsKMoFindDevices(AcqrsKMoDevExtension* dxP, char* vendorStringP)
{
	ULONG ndev = 0;
    ULONG vendorID = 0;
    ULONG deviceID = 0;
	struct pci_dev* devP = NULL;

	// Should translate the 'vendorString' for Windows 95  (typically 'VEN_14EC') into vendorID
	// Currently, we only support Acqiris
    vendorID = 0x14ec;
    
    // As from the 282, we have the deviceID = 1 telling the PCI interface is not done with 
    // the PLX but with the FPGA. Thus we must search any deviceID (-1).
    deviceID = -1;

	while ( (devP = pci_find_device(vendorID, deviceID, devP)) )
	{
		// printk("Acqiris: tried to config the device  \n" );	// maybe this needs some more prog pci_find_subsys ; see pci.txt in Documentation
		if (dxP != NULL)
		{
		    if (pci_enable_device(devP))     
		        continue;

     		pci_set_master (devP);	
            
            dxP->vendorID = devP->vendor;
            dxP->deviceID = devP->device;
            dxP->flagsInit = 0;
            
		    dxP->res.controlAddr = pci_resource_start(devP, 0);

			dxP->res.controlSize	= pci_resource_len(devP, 0);			//PCI 9080 memory addr space
			if (dxP->res.controlAddr == 0)
				dxP->res.controlBase = 0;
			else
				dxP->res.controlBase = (long)ioremap_nocache(dxP->res.controlAddr, dxP->res.controlSize); 
								

			if( (pci_resource_flags (devP, 1) & IORESOURCE_IO) && (pci_resource_flags (devP, 2) & IORESOURCE_MEM) )
			{
				if(dbgl&DINIT) printk("Acqiris: using BAR2 for mem IO \n \n" );
				dxP->res.directAddr	 = pci_resource_start(devP, 2);
				dxP->res.directSize	 = pci_resource_len(devP, 2);			// Acqiris Module memory addr space
			}
			else if( (pci_resource_flags (devP, 1) & IORESOURCE_MEM) )
			{
				if(dbgl&DINIT) printk("Acqiris: using BAR1 for mem IO \n" );
				dxP->res.directAddr	 = pci_resource_start(devP, 1);
				dxP->res.directSize	 = pci_resource_len(devP, 1);			// Acqiris Module memory addr space
			}
			else
			{
				printk("Acqiris: invalid IO Resources  \n" );
			}
			
			if (dxP->res.directAddr == 0)
				dxP->res.directBase = 0;
			else
				dxP->res.directBase = (long)ioremap_nocache(dxP->res.directAddr, dxP->res.directSize);

			dxP->res.interrupt		= devP->irq;
			dxP->res.IRQHandle		= 0;	// Initialize to 'non-hooked'
			pci_write_config_byte(devP, PCI_INTERRUPT_LINE, dxP->res.interrupt);  

			dxP->res.busNumber = (long)devP->bus->number;
			dxP->devfn = (long)devP->devfn;
			dxP->res.devNumber = (long)PCI_SLOT(devP->devfn);

			if(dbgl&DINIT) {
					//printk("<1>Acqiris: DBGL %x \n", dbgl);
					printk("<1>Acqiris: Board %d, bus %d, irq %d\n",PCI_SLOT(devP->devfn),devP->bus->number, devP->irq);
			 		printk("<1>Acqiris: control address [0] 0x%x size 0x%x \n",(unsigned int)dxP->res.controlAddr,(unsigned int)dxP->res.controlSize );
				 	printk("<1>Acqiris: control address [2] 0x%x size 0x%x \n",(unsigned int)pci_resource_start(devP, 2),(unsigned int)dxP->res.directSize );
					}

			init_waitqueue_head(&dxP->endAcqEventP);
			init_waitqueue_head(&dxP->endProcEventP);
			init_waitqueue_head(&dxP->dmaEventP);

			strcpy(dxP->res.name, "Acqiris");
			dxP++;
		}
		ndev++;
	}
	AcqrsKMoNbrDevices = ndev;		// report # of devices found
	return ERROR_SUCCESS;
}
