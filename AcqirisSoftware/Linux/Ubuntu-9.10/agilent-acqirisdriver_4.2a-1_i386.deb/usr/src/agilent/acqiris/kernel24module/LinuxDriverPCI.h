//////////////////////////////////////////////////////////////////////////////////////////
//
//  LinuxDriverPCI.h	Declarations for Linux Kernel-Space Device Driver for PCI9080-based Acqiris Devices
//
//----------------------------------------------------------------------------------------
//  Copyright 2000 Acqiris. All rights reserved.
//
//  Started:	 6 JUN 2000
//
//  Owned by:	V. Hungerbuhler
//
//////////////////////////////////////////////////////////////////////////////////////////
#ifndef _LINUXDRIVERPCI_H
#define _LINUXDRIVERPCI_H

//// first define the kernel version we are compiling for //////////////////////
#include <linux/version.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
#define LINUX_2_4
#endif

typedef struct
{
	ULONG dest,
	src,
	size,
	next;
} DMAPLXPageDesc_T;

typedef struct
{
	ULONG destLo,
	destHi,
	size,
	next;
} DMAFPGAPageDesc_T;

#define LNX_MAJOR		1
#define LNX_MINOR		4
#define LNX_VERSION 	((0x100 * LNX_MAJOR) + LNX_MINOR)

typedef long			BOOL;
typedef unsigned char	UCHAR;
#define TRUE	1
#define FALSE	0

#define DEVICE_INTERRUPTCLEAR_OFFSET	0xc			// Interrupt Clear register (offset wrt ctrl/status!)
#define DISABLE_AUTOCLEAR				0x80000000	// Disables interrupt clear on reading

//////////////////////////////////////////////////////////////////////////////////////////
//  Definition of Debug Output Levels
//////////////////////////////////////////////////////////////////////////////////////////

#define DDMA	0x01	// DMA debug 
#define DINT	0x02	// interrupt function
#define DIRW	0x04	// read/write access
#define DAEW	0x08	// end of acquisition
#define DINIT	0x10	// initialization


/***************************************
 * Memory access functions/macros      *
 ***************************************/

#define ac_writeb(port,val)     {writeb((uchar)(val),(ulong)(port)); mb();}
#define ac_writew(port,val)     {writew((ushort)(val),(ulong)(port)); mb();}
#define ac_writel(port,val)     {writel((ulong)(val),(ulong)(port)); mb();}

#define ac_readb(port)  readb(port)
#define ac_readw(port)  readw(port)
#define ac_readl(port)  readl(port)

//////////////////////////////////////////////////////////////////////////////////////////
//  Definition of Global Variables of Linux Kernel-mode Driver
//////////////////////////////////////////////////////////////////////////////////////////
#ifdef LINUXDRIVERPCI_C
ULONG	AcqrsKMoNbrDevices = 0;		// Initialize to 'no devices present'
ULONG	AcqrsKMoDevExtensionBase = 0;	// Device Data Pointer
#else
extern	ULONG	AcqrsKMoNbrDevices;
extern	ULONG	AcqrsKMoDevExtensionBase;
#endif



//////////////////////////////////////////////////////////////////////////////////////////
// Device extension structure
//////////////////////////////////////////////////////////////////////////////////////////

typedef struct
{
	DDrResources	res;
    unsigned int devfn;
    unsigned short vendorID;
    unsigned short deviceID;
    
    long flagsInit;
    
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2,4,0))
	struct wait_queue	*dmaEventP;
	struct wait_queue	*endAcqEventP;
	struct wait_queue	*endProcEventP;
#else
	wait_queue_head_t	dmaEventP;
	wait_queue_head_t	endAcqEventP;
	wait_queue_head_t	endProcEventP;
#endif

	long waitForInt;
} AcqrsKMoDevExtension;


#define DXP_INIT_IRQ        1


//////////////////////////////////////////////////////////////////////////////////////////
// Define constants which are specific to the PLX9080/9054 PCI interface Chip
//////////////////////////////////////////////////////////////////////////////////////////
#define	MARBR_OFFSET		0x08			// Addr offset of Mode/Arbitration register
#define	BIGEND_OFFSET		0x0c			// Addr offset of big/little endian register
#define EROMBA				0x14			// Addr offset of BREQo control
#define DMPBAM				0x28			// Addr offset of direct master to PCI memory
#define MAILBOX7_OFFSET		0x5c			// Addr offset of Mailbox 7
#define	INTSRC_OFFSET		0x68			// Addr offset of Interrupt/Status register
#define CNTRL_OFFSET		0x6c			// Addr offset of CNTRL register
#define	DMA0MODE_OFFSET		0x80			// Addr offset of DMA0 mode register
#define	DMA0DESC_OFFSET		0x90			// Addr offset of DMA0 descriptor pointer
#define	DMA0CSR_OFFSET		0xa8			// Addr offset of DMA0 command/status register

#define	DMA_THR			0xb0			// Addr offset of DMA threshold register

#define	MARBR_PCI_REQ_MODE	0x00800000		// MARBR:  Enable REQ deassertion in master cycles

#define	INTSRC_DMA_INT_EN	0x00040000		// INTSRC: Enable bit for DMA0 interrupt
#define	INTSRC_LOCAL_INT_EN	0x00000800		// INTSRC: Enable bit for module interrupt
#define	INTSRC_PCI_INT_EN	0x00000100		// INTSRC: Enable bit for interrupt on PCI-bus
#define	INTSRC_DMA_ACTIVE	0x00200000		// INTSRC: Activity bit for DMA0 interrupt
#define	INTSRC_LOCAL_ACTIVE	0x00008000		// INTSRC: Activity bit for module interrupt

#define EEPROM_PROGENABLE	0x00010000		// CNTRL: Control bit for EEPROM program-enable
#define EEPROM_CLOCK		0x01000000		// CNTRL: Control bit for EEPROM clock
#define EEPROM_CHIPSEL		0x02000000		// CNTRL: Control bit for EEPROM chip-select		
#define EEPROM_WRITE		0x04000000		// CNTRL: Control bit for EEPROM write
#define EEPROM_READ			0x08000000		// CNTRL: Control bit for EEPROM read
#define EEPROM_CLEARBITS	0x0f010000		// CNTRL: Combination of the 5 bits above
#define CNTRL_RESET			0x40000000		// CNTRL: PCI Adapter Software Reset

#define	DMA0MODE_READY_EN	0x00000040		// DMA0MODE: Ready Input Enable
#define	DMA0MODE_BTERM		0x00000080		// DMA0MODE: BTERM# input enable (needed!)
#define DMA0MODE_LOCALBRST	0x00000100		// DMA0MODE: Local Bursting enable
#define DMA0MODE_CHAINING	0x00000200		// DMA0MODE: Chaining enable
#define DMA0MODE_INTENABLE	0x00000400		// DMA0MODE: Interrupt enable (at end of Xfer)
#define DMA0MODE_CONSTANT	0x00000800		// DMA0MODE: 1 = keeps local address constant
#define DMA0MODE_PCIINTRPT	0x00020000		// DMA0MODE: 1 = sends interrupt to PCI bus

#define DMA0MODE (DMA0MODE_READY_EN		|	DMA0MODE_BTERM		|	\
				  DMA0MODE_CHAINING		|	DMA0MODE_LOCALBRST	|	\
				  DMA0MODE_INTENABLE	|	DMA0MODE_CONSTANT	|	\
				  DMA0MODE_PCIINTRPT	)

#define	DMA0CSR_ENABLE		0x00000001		// DMA0CSR: Enable transfer
#define	DMA0CSR_START		0x00000002		// DMA0CSR: Start transfer
#define	DMA0CSR_ABORT		0x00000004		// DMA0CSR: Abort transfer
#define	DMA0CSR_CLRINTRPT	0x00000008		// DMA0CSR: Clear DMA0 interrupts
#define	DMA0CSR_CHAN_DONE	0x00000010		// DMA0CSR: 'Channel Done' indicator

#define PCI_ID_OFFSET		0x00			// PCI-Config Space: deviceID + vendorID
#define PCI_CR_OFFSET		0x04			// PCI-Config Space: control register
#define PCI_HDR_OFFSET		0x0c			// PCI-Config Space: header type etc.
#define PCI_BAR0_OFFSET		0x10			// PCI-Config Space: base address register 0
#define PCI_BAR2_OFFSET		0x18			// PCI-Config Space: base address register 2
#define PCI_INTRPT_OFFSET	0x3c			// PCI_Config Space: interrupts etc.


//////////////////////////////////////////////////////////////////////////////////////////
//  Definition of Global Function Prototypes
//////////////////////////////////////////////////////////////////////////////////////////
int AcqrsKMoCntrl(struct inode* inodeP, struct file* fileP, unsigned int cmd, ULONG private);
int	AcqrsKMoOpen(struct inode* inodeP, struct file* fileP);
int	AcqrsKMoRelease(struct inode* inodeP, struct file* fileP);

ULONG AcqrsKMoConfOps(ULONG cmd, DDrLinuxIO* ioBlkP);
ULONG AcqrsKMoUserOps(ULONG cmd, DDrLinuxIO* ioBlkP);

AcqrsKMoDevExtension* AcqrsKMoGetDevExtension(ULONG device);
void AcqrsKMoProgressLog(char* strP, long device);

//////////////////////////////////////////////////////////////////////////////////////////
//  Definition of VxD Macros
//////////////////////////////////////////////////////////////////////////////////////////

#define READ_REGISTER_ULONG(x)     ( *(volatile ULONG * const)(x) )

#define WRITE_REGISTER_ULONG(x,y)  *(volatile ULONG * const)(x) = y;


#endif // _LINUXDRIVERPCI_H

