//////////////////////////////////////////////////////////////////////////////////////////
//
//  LinuxDriverPCI.c	Implementation of Linux Kernel-Space Device Driver
//						for PCI9080&PCI9054-based Acqiris Devices
//
//----------------------------------------------------------------------------------------
//  Copyright 2001 Acqiris. All rights reserved.
//
//  Started:	6 JUN 2000
//		20/04/01 esch: test on 2.2 kernel
//		26/04/01 esch: added needed changes to get it going on 2.4. kernel
//			 esch: major changes are in the scheduler queue and in the module  initialization
//		22/06/01 esch: implemented use of DMA with kiobuf
//		26/06/01 esch: debug level can be set during load dbgl=N
//		17/07/01 esch: timing and return code in IOCTL_ACQEND_WAITFOR adapted to Windows driver
//		18/07/01 esch: only one application can open the driver succesfully			
//	from here on this is DriverVersion 1.00  any changes increase the last digit by one
//		27/12/01 esch: added DMA write into module
//		15/01/02 esch: DDR_WAIT_1USEC set for 1000 loop cycles 		
//		26/04/02 esch: added interrupt handling for processing
//		20/11/03 esch: replaced page_address, pci_map_page to support virtual - physcal mapping of more than 760 MB
//		17/02/04 esch: sometimes we had interrupt timeouts reported even if the interrupt was cleared
//		17/02/04 esch: timeout value for DMA is now dynamically calculated in jiffies
//
//  Owned by:	V. Hungerbuhler & E. Schaefer
//	
//
// 		
//////////////////////////////////////////////////////////////////////////////////////////
#define LINUXDRIVERPCI_C		// force storage allocation of globally visible variables here

#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/version.h>
#include <linux/delay.h>

#include <linux/sched.h>

#include "DDrIORules.h"
#include "LinuxDriverPCI.h"

#include <linux/init.h>
#include <linux/devfs_fs_kernel.h>
#include <linux/iobuf.h>
#include <linux/pci.h>

#include <asm/current.h>
#include <asm/io.h>
#include <asm/page.h>
#include <asm/pgtable.h>
#include <asm/uaccess.h>
#include <linux/mm.h>
#include <linux/wrapper.h>

#define DMA_DESC_SIZE 0x1000

ULONG AcqrsKMoDMARead(ULONG device, ULONG localAddr, ULONG nbrLong, ULONG dstLinAddr);
ULONG AcqrsKMoDMAWrite(ULONG device, ULONG localAddr, ULONG nbrLong, ULONG srcLinAddr);
void  AcqrsKMoOnInterrupt(int irq, void* private, struct pt_regs* regs);

int dma_kiovec_r_plx(ULONG *pAddr, char *, struct kiobuf *iovec[], unsigned long localAddr);
int dma_kiovec_r_fpga(ULONG *pAddr, char *, struct kiobuf *iovec[], unsigned long localAddr, AcqrsKMoDevExtension *dxP);
int dma_kiovec_w_plx(ULONG *pAddr, char *, struct kiobuf *iovec[], unsigned long localAddr);
int dma_kiovec_w_fpga(ULONG *pAddr, char *, struct kiobuf *iovec[], unsigned long localAddr, AcqrsKMoDevExtension *dxP);

//////////////////////////////////////////////////////////////////////////////////////////
static char DriverName[] = "acqrsPCI";
static char DriverVersion[] = "ver 1.4.2";
static long MajorNumber = 124;
static long Verbose = 0;
/* here's the pointer to the dma desc */
static char *dmadesc; 	
static struct kiobuf * iobuf;
long dbgl = 0;		// for dbg

MODULE_AUTHOR("Viktor Hungerbuhler & Erich Schaefer");
MODULE_DESCRIPTION("Driver for Acqiris Digitizers on PCI-bus");
MODULE_PARM(MajorNumber, "l"); // can be modified with 'insmod acqrsPCI MajorNumber=N'
MODULE_PARM(DriverName,  "s"); // can be modified with 'insmod acqrsPCI DriverName="bla"'
MODULE_PARM(Verbose,     "l"); // can be modified with 'insmod acqrsPCI Verbose=N'
MODULE_PARM(dbgl, "i");
//MODULE_LICENSE("Proprietary");

static struct file_operations AcqrsKMoFileOps = {
	owner:		THIS_MODULE,
	ioctl:		AcqrsKMoCntrl,
	open:		AcqrsKMoOpen,
	release:	AcqrsKMoRelease,
};

///////////////////////////////////////////// Init and module functions /////////////////////////////////////////////
static devfs_handle_t devfs_handle;

static int __init acqiris_init_driver(void)
{
	struct page *page;
	int err;

	if(devfs_register_chrdev(MajorNumber, DriverName, &AcqrsKMoFileOps)) {
		printk("<1>Acqiris: Unable to register driver\n");
		return -ENODEV;
	}
	devfs_handle = devfs_register(NULL, DriverName, DEVFS_FL_DEFAULT,
				      MajorNumber, 0,
				      S_IFCHR | S_IRUSR | S_IWUSR,
				      &AcqrsKMoFileOps, NULL);

	printk("<1>Acqiris: Initializing module %s driver version %s (kernel version > 2.4.0 )\n", DriverName,DriverVersion);
	printk("<1>Acqiris: Major Number = %ld  --> handle = %ld\n", MajorNumber, (long)devfs_handle);
	printk("<1>Acqiris: debug level = 0x%02x (insmod %s.o dbgl=N) \n",(int )dbgl,DriverName);
	printk("<1>Acqiris: N: 0x1 DMA; 0x2 interrupt function; 0x4 module r/w ioctrl; 0x8 end of acquisition \n");
	printk("<1>Acqiris: N: 0x10 initialization \n");
	
	/*
	 * Allocate descriptor space             
	 */
		 
	dmadesc = kmalloc(DMA_DESC_SIZE, GFP_KERNEL);

	if (dmadesc == NULL) {
			printk("<1>Acqiris:  couldn't  kmalloc dmadesc memory ");
			unregister_chrdev(MajorNumber,DriverName);
			return 0;
			}

	/* now we've got DMA_DESC_SIZE bytes of kernel memory, but it can still be
	   swapped out. We need to stop the VM system from removing our
	   pages from main memory. To do this we just need to set the PG_reserved
	   bit on each page, via mem_map_reserve() macro. */
	   
	for (page = virt_to_page(dmadesc); page < virt_to_page(dmadesc + DMA_DESC_SIZE); page++) {
		mem_map_reserve(page);
        	}

	/* allocation of kiovec */

	if( (err = alloc_kiovec(1, &iobuf)) );
		return err;


	printk("<1>Acqiris: kmalloc buffer 0x%x \n",(unsigned int)dmadesc);

	return 0;
}

module_init(acqiris_init_driver);

//////////////////////////////////////////////////////////////////////////////////////////

static void __exit acqiris_cleanup_driver(void)
{			
	devfs_unregister_chrdev(MajorNumber, DriverName);
	devfs_unregister(devfs_handle);
	printk("<1>Acqiris: Leaving module %s  \n", DriverName);
}
module_exit(acqiris_cleanup_driver);

//////////////////////////////////////////////////////////////////////////////////////////



// Entry point for all 'ioctl' system calls to this driver
//////////////////////////////////////////////////////////////////////////////////////////
int AcqrsKMoCntrl(struct inode* inodeP, struct file* fileP, unsigned int cmd, ULONG private)
{
	DDrLinuxIO* ioBlkP = (DDrLinuxIO*) private;

	ULONG returnValue = AcqrsKMoUserOps((ULONG)cmd, ioBlkP);
	ioBlkP->errorCode = returnValue;

	return 0;
}


//////////////////////////////////////////////////////////////////////////////////////////
ULONG AcqrsKMoUserOps(ULONG cmd, DDrLinuxIO* ioBlkP)
{
	ULONG	code	= cmd;
	ULONG	device	= (code >> 16) - DEV_TYPE;
	ULONG 	value;

	ULONG*	cmdP;
	ULONG*	outP;
	ULONG		outSize;
	ULONG*	NreturnP;
	DDrLinuxIO kioBlkP;

	if ( __copy_from_user(&kioBlkP, ioBlkP, sizeof(DDrLinuxIO)))
			return ERROR_INVALID_PARAMETER;      

	cmdP	= kioBlkP.inBufferP;
	outP	= kioBlkP.outBufferP;
	outSize	= kioBlkP.nOutBufferSize;
	NreturnP = kioBlkP.bytesReturnedP;

	if (outP == NULL)					// non-existing outBuf ==> size is zero!
		outSize = 0;

	if( dbgl&DIRW ) printk("<1>Acqiris: AcqrsKMoUserOps code 0x%x  0x%x\n", (unsigned int)code,(unsigned int)code>>2);
	*NreturnP = 0;						// default value
	code -= (device << 16);					// eliminate device # from code	

	switch (code)
	{
	case IOCTL_ACQEND_WAITFOR:
	  {
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);
		long timeVal = *cmdP;					// cmdP[0] contains timeout in msec
		long timeout = ((timeVal*HZ)/1000) + 1;			// timeout in 'jiffies'
		long timeToExpire =1;
		
  		DECLARE_WAITQUEUE(waitA, current);

		if (outSize < 4)
			return ERROR_BUFFER_OVERFLOW;

		add_wait_queue(&dxP->endAcqEventP, &waitA);

		set_current_state(TASK_INTERRUPTIBLE);

		dxP->waitForInt = DDR_ACQEND_INTERRUPT;
		// Enable the EofA interrupt
		WRITE_REGISTER_ULONG(dxP->res.intrptLocalAddr, DDR_ACQEND_INTERRUPT);

		timeToExpire = schedule_timeout(timeout);	

		remove_wait_queue(&dxP->endAcqEventP, &waitA);

		// Disable all interrupts
		WRITE_REGISTER_ULONG(dxP->res.intrptLocalAddr, 0L);

		// If no timeout occurred, we report the current value of the interrupt 
		// status register (which is never -1). The calling routine must interpret
		// the meaning of the bits.

		*outP = READ_REGISTER_ULONG(dxP->res.intrptLocalAddr);

		// in some cases we get a timout even if we cleared the interrupt (seen on RH 8.0)
		if (timeToExpire == 0 && (dxP->waitForInt & DDR_ACQEND_INTERRUPT) )				// Timeout occurred!
			*outP |= DDR_TIMEOUT_MARKER;		// set the TIMEOUT MARKER
		else 
			*outP &= ~DDR_TIMEOUT_MARKER; 
			
		dxP->waitForInt = 0;
		
		if(dbgl&DAEW) printk("<1>Acqiris: IOCTL_ACQEND_WAITFOR: timeout set %d reached %d [%d ms] int reg: 0x%x timeval %d \n",(unsigned int)timeout,(unsigned int)timeToExpire,(unsigned int)1000/HZ,(unsigned int)*outP,(unsigned int)timeVal);

		*NreturnP = 4;
	  }
		break;
		
	case IOCTL_PROCESS_WAITFOR:
	  {
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);
		long timeVal = *cmdP;					// cmdP[0] contains timeout in msec
		long timeout = ((timeVal*HZ)/1000) + 1;	// timeout in 'jiffies'
		long timeToExpire =1;

  		DECLARE_WAITQUEUE(waitP, current);

		if (outSize < 4)
			return ERROR_BUFFER_OVERFLOW;

 	// See also the comments under IOCTL_ACQEND_WAITFOR above!

		add_wait_queue(&dxP->endProcEventP, &waitP);

		set_current_state(TASK_INTERRUPTIBLE);

		dxP->waitForInt = DDR_PROCEND_INTERRUPT;
		// Enable the EofP interrupt

		WRITE_REGISTER_ULONG(dxP->res.intrptLocalAddr, DDR_PROCEND_INTERRUPT);

		timeToExpire = schedule_timeout(timeout);

		remove_wait_queue(&dxP->endProcEventP, &waitP);

		// Disable all interrupts
		WRITE_REGISTER_ULONG(dxP->res.intrptLocalAddr, 0L);

		// If no timeout occurred, we report the current value of the interrupt 
		// status register (which is never -1). The calling routine must interpret
		// the meaning of the bits.

		*outP = READ_REGISTER_ULONG(dxP->res.intrptLocalAddr);

		// it can happen that we get a timout even if we cleared the interrupt (seen on RH 8.0)
		if (timeToExpire == 0 && (dxP->waitForInt & DDR_PROCEND_INTERRUPT) )	// Timeout occurred!
			*outP |= DDR_TIMEOUT_MARKER;		// set the TIMEOUT MARKER
		else 
			*outP &= ~DDR_TIMEOUT_MARKER; 
			
		dxP->waitForInt = 0;
		
		if(dbgl&DAEW) printk("<1>Acqiris: IOCTL_PROCESS_WAITFOR: timeout set %d reached %d [%d ms] int reg: 0x%x timeval %d \n",(unsigned int)timeout,(unsigned int)timeToExpire,(unsigned int)1000/HZ,(unsigned int)*outP,(unsigned int)timeVal);

		*NreturnP = 4;
	  }
		break;

	case IOCTL_INIT:						// Initialize a device + hook interrupt
	  {
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);

		ULONG* dma0CsrP		 = (ULONG*)(dxP->res.controlBase + DMA0CSR_OFFSET);
		ULONG* plxIntrptRegP = (ULONG*)(dxP->res.controlBase + INTSRC_OFFSET);
		ULONG* marbRegP	= (ULONG*)(dxP->res.controlBase + MARBR_OFFSET);
		ULONG* intrptClearRegP;

		if ( (AcqrsKMoNbrDevices == 0) || (device >= AcqrsKMoNbrDevices) )
			return ERROR_INVALID_PARAMETER;

		if(dbgl&DINIT) AcqrsKMoProgressLog("IOCTL_INIT device", device);

		WRITE_REGISTER_ULONG(dma0CsrP, DMA0CSR_CLRINTRPT);

		// NOTE: We use the device extension pointer 'dxP' rather than 'device' as the
		// private 'dev_id' argument. See Rubini, p.200 !
        if (  (dxP->flagsInit & DXP_INIT_IRQ) == 0  )
        {
            if (request_irq(dxP->res.interrupt, AcqrsKMoOnInterrupt, SA_SHIRQ | SA_INTERRUPT,"Acqiris" , (void*)dxP) != 0)
            {
                AcqrsKMoProgressLog("IOCTL_INIT: request_irq failed", device);
                return ERROR_NOACCESS;
            }
            
            dxP->flagsInit |= DXP_INIT_IRQ;
        }
        
		dxP->res.intrptLocalAddr = (long)((UCHAR*)dxP->res.directBase + cmdP[0]);
		intrptClearRegP = (ULONG*)(dxP->res.intrptLocalAddr + DEVICE_INTERRUPTCLEAR_OFFSET);

	// NOTE: The first line clears interrupts in devices without AutoClear capability
	//		 The third line clears interrupts and disables AutoClear (is available)
	// A "non-applicable" operation does not disturb a device!
		value = READ_REGISTER_ULONG(dxP->res.intrptLocalAddr);		// Read to clear
		value = DISABLE_AUTOCLEAR + 0x1fffffff;
		WRITE_REGISTER_ULONG(intrptClearRegP, value);				// Clear   all interrupts
		WRITE_REGISTER_ULONG(dxP->res.intrptLocalAddr, 0L);			// Disable all interrupts

		value = READ_REGISTER_ULONG(marbRegP);
		value |= 0x01000000;	// for the rev 2.1 mode , bit 24		
		WRITE_REGISTER_ULONG(marbRegP,value);

		// Unmask the PLX interface interrupt, the module interrupt and the DMA interrupt
		value  = READ_REGISTER_ULONG(plxIntrptRegP);
		value |= (INTSRC_PCI_INT_EN | INTSRC_LOCAL_INT_EN);
		WRITE_REGISTER_ULONG(plxIntrptRegP, value);

		// Report initialization to Error Log
		if(dbgl&DINIT) AcqrsKMoProgressLog("IOCTL_INIT OK device", device);
	  }
		break;

	case IOCTL_INTRPT_STATUS:
	  {		
	  	AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);
		ULONG* intrptClearRegP = (ULONG*)(dxP->res.intrptLocalAddr + DEVICE_INTERRUPTCLEAR_OFFSET);
		ULONG  value;

		*outP = READ_REGISTER_ULONG(dxP->res.intrptLocalAddr);	// Read status register

	// Since we disable the interrupt-autoclear , we need to clear explicitly
		value = DISABLE_AUTOCLEAR + *outP;
		WRITE_REGISTER_ULONG(intrptClearRegP, value);

		*NreturnP = 4;
	  }
		break;

	case IOCTL_READ:						// Read data from incrementing address in device
	case IOCTL_READ_BLK:					// Read data from fixed address in device
	  {
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);
		ULONG	localAddr    = cmdP[0];		// Local address in PCI module
		ULONG	i, nbrLongs  = cmdP[1];		// # longs to read
		UCHAR*	directRegP;

		if ( (AcqrsKMoNbrDevices == 0) || (device >= AcqrsKMoNbrDevices) )
			return ERROR_INVALID_PARAMETER;

		*NreturnP = 4*nbrLongs;				// Preset! Might need correction if abort
		if (outSize < *NreturnP)
			return ERROR_BUFFER_OVERFLOW;

		directRegP = (UCHAR*)dxP->res.directBase;

		for (i = 0; i < nbrLongs; i++)
		{
			*outP++ = READ_REGISTER_ULONG(directRegP + localAddr);
			if (code == IOCTL_READ)
				localAddr += 4;
		}
	  }
		break;

	case IOCTL_READ_DMA:					// Read (32-bit) data from a device via DMA
	  {
		if ( (AcqrsKMoNbrDevices == 0) || (device >= AcqrsKMoNbrDevices) )
			return ERROR_INVALID_PARAMETER;

		*NreturnP = 4*cmdP[1];				// Preset! Might need correction if abort
		if (outSize < *NreturnP)
			return ERROR_BUFFER_OVERFLOW;

		if (cmdP[1] > DDR_MAX_DMABLOCK)			// cmdP[1] = # longs to transfer!
			return ERROR_INVALID_PARAMETER;

		return AcqrsKMoDMARead(device, cmdP[0], cmdP[1], (ULONG)outP);
	  }
		break;


/*********************************/
	case IOCTL_READ_WRITE:					// Read/Write dispersed data from/to a device
	  {
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);
		ULONG	nbrCmds    = cmdP[0];		// # commands to execute
		ULONG	nbrToRead  = cmdP[1];		// # values to read
		ULONG	i, nbrRead = 0;
		UCHAR*	directRegP;
		UCHAR*	controlRegP;

		if ( (AcqrsKMoNbrDevices == 0) || (device >= AcqrsKMoNbrDevices) )
			return ERROR_INVALID_PARAMETER;

		*NreturnP = 4*nbrToRead;			
		if (outSize < *NreturnP)
			return ERROR_BUFFER_OVERFLOW;

		directRegP  = (UCHAR*)dxP->res.directBase;
		controlRegP = (UCHAR*)dxP->res.controlBase;

		if(dbgl&DIRW) {
			printk("<1>Acqiris: IOCTL_READ_WRITE nbrCmds %d values to read %d \n",(unsigned int)nbrCmds,(unsigned int)nbrToRead);
			printk("<1>Acqiris: IOCTL_READ_WRITE directRegP 0x%x controlRegP 0x%x \n",(unsigned int)directRegP,(unsigned int)controlRegP);
			for (i = 0; i < nbrCmds; i++)
				printk("<1>Acqiris: IOCTL_READ_WRITE %d localAddr 0x%x value 0x%x \n",(unsigned int)i,(unsigned int)cmdP[2 + 2*i],(unsigned int)cmdP[3 + 2*i]);
				}
				
		for (i = 0; i < nbrCmds; i++)
		{
			ULONG j;
			ULONG localAddr = (cmdP[2 + 2*i])&(~DDR_READ_WRITE_MASK);
			ULONG value	    =  cmdP[3 + 2*i];

			switch(cmdP[2 + 2*i] & DDR_READ_WRITE_MASK)
			{
			case DDR_WRITE_DEV:				// value = value to write to register
				
				WRITE_REGISTER_ULONG(directRegP + localAddr, value);

				WRITE_REGISTER_ULONG(controlRegP + MAILBOX7_OFFSET, value);
				break;
			
			case DDR_READ_DEV_INC:			// value = number of read operations
				for (j = 0; j < value; j++)
				{
					*outP++ = READ_REGISTER_ULONG(directRegP + localAddr);
					localAddr++;
					if (++nbrRead > nbrToRead)
						return ERROR_BUFFER_OVERFLOW;
				}
				break;

			case DDR_READ_DEV_FIXED:		// value = number of read operations
			
				if(dbgl&DIRW)  printk("<1>Acqiris: DDR_READ_DEV_FIXED  localAddr 0x%x \n",(unsigned int)localAddr );
				for (j = 0; j < value; j++)
				{
					*outP++ = READ_REGISTER_ULONG(directRegP + localAddr);
					if (++nbrRead > nbrToRead)
						return ERROR_BUFFER_OVERFLOW;
					if(dbgl&DIRW)  printk("<1>Acqiris: DDR_READ_DEV_FIXED  retval 0x%x \n",(unsigned int)*(outP-1) );		
				}
				break;

			case DDR_WRITE_IFACE:			// value = value to write to register

				WRITE_REGISTER_ULONG(controlRegP + localAddr, value);
				break;

			case DDR_READ_IFACE:

				*outP++ = READ_REGISTER_ULONG(controlRegP + localAddr);

				if (++nbrRead > nbrToRead)
					return ERROR_BUFFER_OVERFLOW;
				break;

			case DDR_WAIT_1USEC:			// value = should be in micro-seconds	
				udelay(value);
			}
		}
	  }
		break;

	case IOCTL_WRITE:						// Write data to incrementing address in device
	case IOCTL_WRITE_BLK:					// Write data to fixed address in device
		{
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);
		ULONG	localAddr    = cmdP[0];		// Local address in PCI module
		ULONG	i, nbrLongs  = cmdP[1];		// # longs to write
		UCHAR*	directRegP;

		if ( (AcqrsKMoNbrDevices == 0) || (device >= AcqrsKMoNbrDevices) )
			return ERROR_INVALID_PARAMETER;

		directRegP = (UCHAR*)dxP->res.directBase;
		
		cmdP += 2;
		for (i = 0; i < nbrLongs; i++)  
		{
			ULONG value = *cmdP++;
			WRITE_REGISTER_ULONG(directRegP + localAddr, value);
			if (code == IOCTL_WRITE ) 
				localAddr += 4;				
		}

		}
		break;
				
	case IOCTL_WRITE_DMA:					// Write (32-bit) data to a device via DMA
		{	
		// DMA to localbus is only supported for the RC200 
		// which reflects in writing to 520
	  		 
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);
		ULONG	localAddr    = cmdP[0];		// Local address in PCI module
		ULONG	i, nbrLongs  = cmdP[1];		// # longs to write
		UCHAR*	directRegP;

		char plxSwap = 0; 
		ULONG* bigendP		= (ULONG*)(dxP->res.controlBase + BIGEND_OFFSET);
		ULONG bval = 0;
	
		if( localAddr == 0x520 ) 
		{
			if ( (AcqrsKMoNbrDevices == 0) || (device >= AcqrsKMoNbrDevices) )
				return ERROR_INVALID_PARAMETER;

			if (cmdP[1] > DDR_MAX_DMABLOCK)		// cmdP[1] = # longs to transfer!
				return ERROR_INVALID_PARAMETER;

			return AcqrsKMoDMAWrite(device, cmdP[0], cmdP[1], (ULONG)outP);
						
			plxSwap = 1;
			bval = READ_REGISTER_ULONG(bigendP);	
			WRITE_REGISTER_ULONG(bigendP, (int)( bval|0x80 ));	// set DMA 0 into big endian data ordering
		}
		else
		{
			ULONG* src = (ULONG *)outP;
			directRegP = (UCHAR*)dxP->res.directBase;
		
			for (i = 0; i < nbrLongs; i++)  
			{
				ULONG value = *src++;
				WRITE_REGISTER_ULONG(directRegP + localAddr, value);
				if (code == IOCTL_WRITE && localAddr != 0x520) 
					localAddr += 4;
					
			}
		
		}
	
		if(plxSwap)
			WRITE_REGISTER_ULONG(bigendP, (int)( bval ));	
	  	}
		break;
		
	default:								// Treat other IOCTLs
		return AcqrsKMoConfOps(cmd, ioBlkP);
	}


    return ERROR_SUCCESS;
}


//////////////////////////////////////////////////////////////////////////////////////////
ULONG AcqrsKMoDMARead(ULONG device, ULONG localAddr, ULONG nbrLong, ULONG dstLinAddr)
{
	AcqrsKMoDevExtension *dxP = AcqrsKMoGetDevExtension(device);
	long timeToExpire;
	int err;

  	DECLARE_WAITQUEUE(wait, current);

	ULONG* dma0ModeP	= (ULONG*)(dxP->res.controlBase + DMA0MODE_OFFSET);
	ULONG* dma0DescP	= (ULONG*)(dxP->res.controlBase + DMA0DESC_OFFSET);
	ULONG* dma0CsrP		= (ULONG*)(dxP->res.controlBase + DMA0CSR_OFFSET);
	ULONG* plxIntrptRegP= (ULONG*)(dxP->res.controlBase + INTSRC_OFFSET);
	
    char *descP;
    ULONG value;
	ULONG nbrPage;

	if( (err = map_user_kiobuf(READ,iobuf, (unsigned long)dstLinAddr, nbrLong*4)) ) {
			printk("<1>Acqiris: map_user_kiobuf failed . 0x%x \n",err); // here we still have a problem
			printk("<1>Acqiris: iobuf remap virt addr %08x nbrLong %08x\n",(unsigned int)dstLinAddr,(unsigned int)nbrLong);
			if( err == -EINVAL ) {
				printk("<1>Acqiris: iobuf already mapped . nb_pages %d \n",iobuf->nr_pages);
				if(iobuf->nr_pages)
					unmap_kiobuf(iobuf);
				}
			return 0;
			}
			
	if(dbgl&DDMA) printk("<1>Acqiris: iobuf virt addr %08x nbrLong %08x\n",(unsigned int)dstLinAddr,(unsigned int)nbrLong);			
	
	nbrPage = iobuf->nr_pages;

    	// init the dma chain

    descP = (char *)virt_to_phys(dmadesc);
    
    if (dxP->deviceID == 0)
	    dma_kiovec_r_plx((ULONG *)dmadesc, descP, &iobuf, localAddr);
    else
	    dma_kiovec_r_fpga((ULONG *)dmadesc, descP, &iobuf, localAddr, dxP);
    
    WRITE_REGISTER_ULONG(dma0DescP, (int)(descP + 0x9));

	// Set the DMA mode
	value = READ_REGISTER_ULONG(dma0ModeP);		
	value |= DMA0MODE;
	WRITE_REGISTER_ULONG(dma0ModeP, value);

	// first add yourself to the wait queue then inable the interrupt
	// otherwise the interrupt handler will crash

	add_wait_queue(&dxP->dmaEventP, &wait);

	set_current_state(TASK_INTERRUPTIBLE);

	value = (DMA0CSR_CLRINTRPT | DMA0CSR_ENABLE);	
	WRITE_REGISTER_ULONG(dma0CsrP, value);

	// Enable DMA interrupt at the level of the global interrupt
	value  = READ_REGISTER_ULONG(plxIntrptRegP);
	value |= INTSRC_DMA_INT_EN;
	WRITE_REGISTER_ULONG(plxIntrptRegP, value);

	value = (DMA0CSR_ENABLE | DMA0CSR_START);	
	WRITE_REGISTER_ULONG(dma0CsrP, value);				// Start actual DMA transfer by enabling device

	// DMA transfer speed is about 100 MB/sec
	// value should correspond to a transfer time needed to transfer 100 MB + requested amount of MB 

	value = (100 + (nbrLong>>20))* HZ/100;
	timeToExpire = schedule_timeout( value );			// value is given in jiffies   	

	remove_wait_queue(&dxP->dmaEventP, &wait);
		
	if (!timeToExpire) {						// Did we return because of timeout?
	
		value  = READ_REGISTER_ULONG(dma0CsrP);			// Test only!

		// Abort the DMA
		WRITE_REGISTER_ULONG(dma0CsrP, 0);			// Disable DMA0
		value  = READ_REGISTER_ULONG(dma0CsrP);
		if ((value & DMA0CSR_CHAN_DONE) == 0) {			// If DMA not finished yet
			value = DMA0CSR_CLRINTRPT | DMA0CSR_ABORT;	
			WRITE_REGISTER_ULONG(dma0CsrP, value);		// Abort + Clear Interrupt
			}
		else {
			value = DMA0CSR_CLRINTRPT;	
			WRITE_REGISTER_ULONG(dma0CsrP, value);		// Clear Interrupt only
			}

		AcqrsKMoProgressLog("DMA-Timeout occurred", device);
		
		unmap_kiobuf(iobuf);
		return ERROR_TIMEOUT;	// should be called DMA_TIMEOUT 
		}

    unmap_kiobuf(iobuf);			// seemds to be timing sensitiv !

    return ERROR_SUCCESS;	
}


//////////////////////////////////////////////////////////////////////////////////////////
ULONG AcqrsKMoDMAWrite(ULONG device, ULONG localAddr, ULONG nbrLong, ULONG srcLinAddr)
{
	AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);
	long timeToExpire;
	int err;

  	DECLARE_WAITQUEUE(wait, current);
	
	ULONG* dma0ModeP	= (ULONG*)(dxP->res.controlBase + DMA0MODE_OFFSET);
	ULONG* dma0DescP	= (ULONG*)(dxP->res.controlBase + DMA0DESC_OFFSET);
	ULONG* dma0CsrP		= (ULONG*)(dxP->res.controlBase + DMA0CSR_OFFSET);
	ULONG* plxIntrptRegP= (ULONG*)(dxP->res.controlBase + INTSRC_OFFSET);

    	char      *descP;
    	ULONG value;
	ULONG nbrPage;

	if( (err = map_user_kiobuf(WRITE,iobuf, (unsigned long)srcLinAddr, nbrLong*4)) ) {
			printk("<1>Acqiris: map_user_kiobuf failed . 0x%x \n",err); // here we still have a problem
			printk("<1>Acqiris: iobuf remap virt addr %08x nbrLong %08x\n",(unsigned int)srcLinAddr,(unsigned int)nbrLong);
			if( err == -EINVAL ) {
				printk("<1>Acqiris: iobuf already mapped . nb_pages %d \n",iobuf->nr_pages);
				if(iobuf->nr_pages)
					unmap_kiobuf(iobuf);
				}
			return 0;
			}
			
	if(dbgl&DDMA) printk("<1>Acqiris: iobuf virt addr %08x nbrLong %08x\n",(unsigned int)srcLinAddr,(unsigned int)nbrLong);			
	
	nbrPage = iobuf->nr_pages;

    	// init the dma chain

    descP = (char *)virt_to_phys(dmadesc);
    
    if (dxP->deviceID == 0)
        dma_kiovec_w_plx((ULONG *)dmadesc, descP, &iobuf, localAddr);
    else
        dma_kiovec_w_fpga((ULONG *)dmadesc, descP, &iobuf, localAddr, dxP);

	WRITE_REGISTER_ULONG(dma0DescP, (int)(descP + 0x1));

	// Set the DMA mode
	value = READ_REGISTER_ULONG(dma0ModeP);		
	value |= DMA0MODE;
	WRITE_REGISTER_ULONG(dma0ModeP, value);

	// first add yourself to the wait queue then enable the interrupt
	// otherwise the interrupt handler will crash

	add_wait_queue(&dxP->dmaEventP, &wait);

	set_current_state(TASK_INTERRUPTIBLE);

	value = (DMA0CSR_CLRINTRPT | DMA0CSR_ENABLE);	
	WRITE_REGISTER_ULONG(dma0CsrP, value);

	// Enable DMA interrupt at the level of the global interrupt
	value  = READ_REGISTER_ULONG(plxIntrptRegP);
	value |= INTSRC_DMA_INT_EN;
	WRITE_REGISTER_ULONG(plxIntrptRegP, value);

	value = (DMA0CSR_ENABLE | DMA0CSR_START);	
	WRITE_REGISTER_ULONG(dma0CsrP, value);				// Start actual DMA transfer by enabling device

	// DMA transfer speed is about 100 MB/sec
	// value should correspond to a transfer time needed to transfer 100 MB + requested amount of MB 

	value = (100 + (nbrLong>>20))* HZ/100;				// value is given in jiffies
	timeToExpire = schedule_timeout( value );	   	

	remove_wait_queue(&dxP->dmaEventP, &wait);
		
	if (!timeToExpire) {						// Did we return because of timeout?
	
		value  = READ_REGISTER_ULONG(dma0CsrP);			// Test only!

		// Abort the DMA
		WRITE_REGISTER_ULONG(dma0CsrP, 0);			// Disable DMA0
		value  = READ_REGISTER_ULONG(dma0CsrP);
		if ((value & DMA0CSR_CHAN_DONE) == 0) {			// If DMA not finished yet
			value = DMA0CSR_CLRINTRPT | DMA0CSR_ABORT;	
			WRITE_REGISTER_ULONG(dma0CsrP, value);		// Abort + Clear Interrupt
			}
		else {
			value = DMA0CSR_CLRINTRPT;	
			WRITE_REGISTER_ULONG(dma0CsrP, value);		// Clear Interrupt only
			}

		AcqrsKMoProgressLog("DMA-Timeout occurred", device);
		
		unmap_kiobuf(iobuf);
		return ERROR_TIMEOUT;	// should be called DMA_TIMEOUT esch
		}

    unmap_kiobuf(iobuf);			// seemds to be timing sensitiv !
    return ERROR_SUCCESS;	
}


//////////////////////////////////////////////////////////////////////////////////////////
AcqrsKMoDevExtension* AcqrsKMoGetDevExtension(ULONG device)
{
	return (AcqrsKMoDevExtension*) (AcqrsKMoDevExtensionBase + device*sizeof(AcqrsKMoDevExtension) );
}


//////////////////////////////////////////////////////////////////////////////////////////
void AcqrsKMoOnInterrupt(int irq, void* private, struct pt_regs* regs)
{
	AcqrsKMoDevExtension* dxP = (AcqrsKMoDevExtension*)private;
	ULONG	plxIntrptReg, value;
	ULONG*	plxIntrptRegP;
	plxIntrptRegP = (ULONG*)(dxP->res.controlBase + INTSRC_OFFSET);
	plxIntrptReg  = READ_REGISTER_ULONG(plxIntrptRegP);		// Read PLX interrupt status

	// We must check every enabled interrupt separately
	// Note that we ONLY service ONE interrupt at a time!! If more than 1 interrupt is set,
	// we expect the second (non-serviced) interrupt to become active again.
	
	if(dbgl&DINT) printk("<1>Acqiris: PLX Interrupt 0x%x \n",(unsigned int)plxIntrptReg);
			
	if ( (plxIntrptReg & INTSRC_DMA_ACTIVE) != 0)	// Treat a DMA interrupt
	{
		ULONG* dma0CsrP		 = (ULONG*)(dxP->res.controlBase + DMA0CSR_OFFSET);
 		
		///////////////////////////////////////////////////////////////////
		// Wake up and disable DMA interrupt at the level of the global interrupt
		///////////////////////////////////////////////////////////////////
		value = READ_REGISTER_ULONG(dma0CsrP);	// Read to CLEAR!
		value |=  DMA0CSR_CLRINTRPT;
		WRITE_REGISTER_ULONG(dma0CsrP, DMA0CSR_CLRINTRPT);		// if it is still running Abort

		wake_up_interruptible(&dxP->dmaEventP);
		return;
	}

	if ( (plxIntrptReg & INTSRC_LOCAL_ACTIVE) != 0)	// Treat a device interrupt
	{
		ULONG* intrptClearRegP = (ULONG*)(dxP->res.intrptLocalAddr + DEVICE_INTERRUPTCLEAR_OFFSET);

		// Treat a local device interrupt
		value = READ_REGISTER_ULONG(dxP->res.intrptLocalAddr);	// Read to CLEAR!
	
		if ( (dxP->waitForInt & DDR_ACQEND_INTERRUPT) && (value & DDR_ACQEND_INTERRUPT) )		// End-of-Acquisition?
		{
			value = DISABLE_AUTOCLEAR + DDR_ACQEND_INTERRUPT;
			WRITE_REGISTER_ULONG(intrptClearRegP, value);				// Clear EofA interrupt
			wake_up_interruptible(&dxP->endAcqEventP);
			dxP->waitForInt = 0;			
			return;
		}

		if ( (dxP->waitForInt & DDR_PROCEND_INTERRUPT) && (value & DDR_PROCEND_INTERRUPT) )		// End-of-Processing?
		{
			value = DISABLE_AUTOCLEAR + DDR_PROCEND_INTERRUPT;
			WRITE_REGISTER_ULONG(intrptClearRegP, value);				// Clear EofP interrupt
			wake_up_interruptible(&dxP->endProcEventP);
			dxP->waitForInt = 0;
			return;
		}

		AcqrsKMoProgressLog("Bad Device Interrupt", -1);

		return;
	}
		// This device did NOT interrupt!
		// NOTE: Contrary to Windows, Linux apparently has no mechanism to report
		//		 if it serviced the interrupt or not!
	if( dbgl&DINT ) printk("<1>Acqiris: Bad PLX Interrupt 0x%x  \n",(unsigned int)plxIntrptReg);
}


//////////////////////////////////////////////////////////////////////////////////////////
int AcqrsKMoOpen(struct inode* inodeP, struct file* fileP)
{
	if (MOD_IN_USE > 1)
		return -EBUSY;

	// reset global variables
	return 0;
}


//////////////////////////////////////////////////////////////////////////////////////////
int AcqrsKMoRelease(struct inode* inodeP, struct file* fileP)
{
	long i;
	
	// Disconnect all interrupt service handles
	for (i = 0; i < AcqrsKMoNbrDevices; i++)
	{
		AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(i);
        
        if (dxP->flagsInit & DXP_INIT_IRQ)
        {
            free_irq(dxP->res.interrupt, (void*)dxP);
            
            dxP->flagsInit &= ~DXP_INIT_IRQ;
        }
    }

	// Deallocate private device memory space
	if (AcqrsKMoDevExtensionBase != 0)
		kfree((void*)AcqrsKMoDevExtensionBase);

  	return ERROR_SUCCESS;
}


//////////////////////////////////////////////////////////////////////////////////////////
// NOTE: if NO device # is associated, set device = -1
// NOTE: for 'device log', set strP = NULL
void AcqrsKMoProgressLog(char* strP, long device)
{
	static long logNumber = 0;
	char buf1[50], buf2[100];

	if (strP)
		printk("<1>Acqiris: AcqrsKMoProgressLog %s  0x%x \n",strP,(unsigned int)device);
	else
		printk("<1>Acqiris: AcqrsKMoProgressLog  0x%x \n",(unsigned int)device);

	return;

	if (Verbose == 0)
		return;

	// Protect against too many lines (but allow 'NULL' case = termination)
	if ((logNumber > 5000) && (strP != NULL))
		return;

	if (strP == NULL)				// Log the device and its parameters
	{
			AcqrsKMoDevExtension* dxP = AcqrsKMoGetDevExtension(device);

			sprintf(buf1, "Device%3ld A", device);
			sprintf(buf2, "Bus#=%3ld Dev#=%3ld", dxP->res.busNumber, dxP->res.devNumber);
			printk("<1>Acqiris: %s    %s\n", buf1, buf2);

			sprintf(buf1, "Device%3ld B", device);
			sprintf(buf2, "CtrlAddr#   %8lx Size %8lx", dxP->res.controlAddr, dxP->res.controlSize);
			printk("<1>Acqiris: %s    %s\n", buf1, buf2);

			sprintf(buf1, "Device%3ld C", device);
			sprintf(buf2, "DirectAddr# %8lx Size %8lx", dxP->res.directAddr, dxP->res.directSize);
			printk("<1>Acqiris: %s    %s\n", buf1, buf2);

			sprintf(buf1, "Device%3ld D", device);
			sprintf(buf2, "Interrupt# %3lx IRQHandle %8lx", dxP->res.interrupt, dxP->res.IRQHandle);
			printk("<1>Acqiris: %s    %s\n", buf1, buf2);
	}
	else
	{
		if (strlen(strP) > 100)				// Truncate to a reasonable length!!
		{
			strP[100] = '\0';
		}

		if (device < 0)
			sprintf(buf1, "%4ld", logNumber);
		else
			sprintf(buf1, "%4ld  Device%3ld", logNumber, device);
		printk("<1>Acqiris: %s    %s\n", buf1, strP);

		logNumber++;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
int dma_kiovec_r_plx(ULONG *pAddr, char *descP, struct kiobuf *iovec[], unsigned long localAddr)
{
	int		err;
	int		length;
	int		i;
	int		pageind;
	int		offset;
	struct kiobuf *	miobuf = NULL;
	struct page *	map;
	DMAPLXPageDesc_T  *dma_pd = (DMAPLXPageDesc_T  *)pAddr; 

	/* since so far we have only one vector */
	int nr = 1;

	/* OK to walk down the iovec doing page IO on each page we find */
	for (i = 0; i < nr; i++) {
		miobuf = iovec[i];
		offset = miobuf->offset;
		length = miobuf->length;
		miobuf->errno = 0;
		if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec # pages 0x%x  offset 0x%x length 0x%x \n",iobuf->nr_pages,miobuf->offset,miobuf->length);

		for (pageind = 0; pageind < miobuf->nr_pages; pageind++) {

			// The structure of a DMA descriptor block (consisting of 4 ULONGs) is described
			// in the PLX9080 manual in Fig. 3-17, p.32
			// The last four bits of the 'Next Descriptor Pointer' are:
			//	0x1 :	1 = PCI-address space (we don't use any local memory for descriptors)
			//	0x2 :	1 = end of chain, 0 = another descriptor follows
			//	0x4 :	1 = interrupt after terminal-count of this descriptor
			//	0x8 :	1 = read from local memory to PCI-bus, 0 = write to local memory

			map  = miobuf->maplist[pageind];

			if (!map) {
				err = -EFAULT;
				return 0;	// 
				}
						
			if(pageind == 0) {
				dma_pd[pageind].src = localAddr;					// Local source address
				dma_pd[pageind].dest = (unsigned long) pci_map_page (0, map, offset&~PAGE_OFFSET, dma_pd[pageind].size, PCI_DMA_FROMDEVICE);				
				dma_pd[pageind].size = (PAGE_SIZE - (offset) > length) ? length : PAGE_SIZE - (offset);				// Number of bytes to transfer
				dma_pd[pageind].next = (miobuf->nr_pages > 1) ? (int)(descP + 16*(pageind+1) + 0x9) : (int)0xf;		// if you add "+9" take care that dmadesc is either NO POINTER or char*
				length -= dma_pd[pageind].size;				
				}
			else {		
				dma_pd[pageind].src = localAddr;					// Local source address
				dma_pd[pageind].dest = (unsigned long) pci_map_page (0, map, 0, dma_pd[pageind].size, PCI_DMA_FROMDEVICE);
				dma_pd[pageind].size = (length > PAGE_SIZE) ? PAGE_SIZE : length;	// Number of bytes to transfer
				dma_pd[pageind].next = (length > PAGE_SIZE) ? (int)(descP + 16*(pageind+1) +  0x9 ): (int)0x0f ;	// if you add "+9" take care that dmadesc is either NO POINTER or char*
				length -= dma_pd[pageind].size;
				}
			
			// terminate if the page desc gets full !!	
			if(pageind >= DMA_DESC_SIZE/sizeof(DMAPLXPageDesc_T)) {
					dma_pd[pageind].next = 0x0f;
					if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec Page descriptor limit reached \n");
					return 0;
					}
					
			if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec dest 0x%x  size 0x%x \n",(unsigned int)dma_pd[pageind].dest,(unsigned int)dma_pd[pageind].size);
		} /* End of page loop */		
	} /* End of iovec loop */
	if(  length ) {
		printk("<1>Acqiris: dma_kiovec: remaining length !! 0x%x \n",length);
		for(pageind = 0; pageind < miobuf->nr_pages; pageind++)
			printk("<1>Acqiris: dma_kiovec: iob offset 0x%x iobuf size 0x%x size 0x%x next 0x%x\n",offset,miobuf->length,(unsigned int)dma_pd[pageind].size,(unsigned int)dma_pd[pageind].next);
		}
	
return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
int dma_kiovec_r_fpga(ULONG *pAddr, char *descP, struct kiobuf *iovec[], unsigned long localAddr, AcqrsKMoDevExtension *dxP)
{
	int err;
	int length;
	int i;
	int pageind;
	int offset;
	struct kiobuf *miobuf = NULL;
	struct page *map;
	DMAFPGAPageDesc_T *dma_pd = (DMAFPGAPageDesc_T *)pAddr; 

	/* since so far we have only one vector */
	int nr = 1;

	/* OK to walk down the iovec doing page IO on each page we find. */
    for (i = 0 ; i < nr ; ++i)
    {
		miobuf = iovec[i];
		offset = miobuf->offset;
		length = miobuf->length;
		miobuf->errno = 0;
		if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec # pages 0x%x  offset 0x%x length 0x%x \n",iobuf->nr_pages,miobuf->offset,miobuf->length);

        for (pageind = 0 ; pageind < miobuf->nr_pages ; ++pageind)
        {
			/* The structure of a DMA descriptor block (consisting of 4 ULONGs) is described
			   in the PLX9080 manual in Fig. 3-17, p.32
			   The last four bits of the 'Next Descriptor Pointer' are:
			  	0x1 :	1 = PCI-address space (we don't use any local memory for descriptors)
			 	0x2 :	1 = end of chain, 0 = another descriptor follows
				0x4 :	1 = interrupt after terminal-count of this descriptor
				0x8 :	1 = read from local memory to PCI-bus, 0 = write to local memory
            */
			map  = miobuf->maplist[pageind];

            if (!map)
            {
				err = -EFAULT;
				return 0;   
			}
						
            if (pageind == 0)
            {
				dma_pd[pageind].destLo = (unsigned long)pci_map_page(0, map, offset&~PAGE_OFFSET, dma_pd[pageind].size, PCI_DMA_FROMDEVICE);				
				dma_pd[pageind].destHi = 0;
				dma_pd[pageind].size = (PAGE_SIZE - (offset) > length) ? length : PAGE_SIZE - (offset);				// Number of bytes to transfer
				dma_pd[pageind].next = (miobuf->nr_pages > 1) ? (int)(descP + 16*(pageind+1)) : (int)0x1;
				length -= dma_pd[pageind].size;				
			}
            else
            {		
				dma_pd[pageind].destLo = (unsigned long)pci_map_page(0, map, 0, dma_pd[pageind].size, PCI_DMA_FROMDEVICE);
				dma_pd[pageind].destHi = 0;
				dma_pd[pageind].size = (length > PAGE_SIZE) ? PAGE_SIZE : length;	// Number of bytes to transfer
				dma_pd[pageind].next = (length > PAGE_SIZE) ? (int)(descP + 16*(pageind+1)): (int)0x01 ;
				length -= dma_pd[pageind].size;
			}
			
			// terminate if the page desc gets full !!	
            if (pageind >= DMA_DESC_SIZE / sizeof(DMAFPGAPageDesc_T))
            {
                dma_pd[pageind].next = 0x0f;
                if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec Page descriptor limit reached \n");
                return 0;
			}
					
			if (dbgl&DDMA) printk("<1>Acqiris: dma_kiovec dest 0x%x  size 0x%x \n",(unsigned int)dma_pd[pageind].destLo,(unsigned int)dma_pd[pageind].size);
        
        } /* End of page loop */
        
    } /* End of iovec loop */
    
	// In the FPGA-implemented interface, we need to transfer the local address separately!
	if (dxP->deviceID != 0)
	{
		ULONG *dmaLocAddrP = (ULONG*)(dxP->res.controlBase + DMA0MODE_OFFSET + 0x8);
        WRITE_REGISTER_ULONG(dmaLocAddrP, localAddr);
        
	}

    if (length)
    {
		printk("<1>Acqiris: dma_kiovec: remaining length !! 0x%x \n",length);
		for(pageind = 0; pageind < miobuf->nr_pages; pageind++)
			printk("<1>Acqiris: dma_kiovec: iob offset 0x%x iobuf size 0x%x size 0x%x next 0x%x\n",offset,miobuf->length,(unsigned int)dma_pd[pageind].size,(unsigned int)dma_pd[pageind].next);
    
    }
	
    return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//	for writing data into the card via DMA
int dma_kiovec_w_plx(ULONG *pAddr,char *descP,struct kiobuf *iovec[],unsigned long localAddr)
{
	int		err;
	int		length;
	int		i;
	int		pageind;
	int		offset;
	struct kiobuf *	miobuf = NULL;
	struct page *	map;
	DMAPLXPageDesc_T  *dma_pd = (DMAPLXPageDesc_T  *)pAddr; 

	/* since so far we have only one vector */
	int nr = 1;

	/* OK to walk down the iovec doing page IO on each page we find. */
	for (i = 0; i < nr; i++) {
		miobuf = iovec[i];
		offset = miobuf->offset;
		length = miobuf->length;
		miobuf->errno = 0;
		if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec # pages 0x%x  offset 0x%x length 0x%x \n",iobuf->nr_pages,miobuf->offset,miobuf->length);

		for (pageind = 0; pageind < miobuf->nr_pages; pageind++) {

			// The structure of a DMA descriptor block (consisting of 4 ULONGs) is described
			// in the PLX9080 manual in Fig. 3-17, p.32
			// The last four bits of the 'Next Descriptor Pointer' are:
			//	0x1 :	1 = PCI-address space (we don't use any local memory for descriptors)
			//	0x2 :	1 = end of chain, 0 = another descriptor follows
			//	0x4 :	1 = interrupt after terminal-count of this descriptor
			//	0x8 :	1 = read from local memory to PCI-bus, 0 = write to local memory

			map  = miobuf->maplist[pageind];

			if (!map) {
				err = -EFAULT;
				return 0;	// check ????
				}
						
			if(pageind == 0) {
				dma_pd[pageind].src = localAddr;					// Local source address
				dma_pd[pageind].dest = (unsigned long) pci_map_page (0, map, offset&~PAGE_OFFSET, dma_pd[pageind].size, PCI_DMA_TODEVICE);				
				dma_pd[pageind].size = (PAGE_SIZE - (offset) > length) ? length : PAGE_SIZE - (offset);				// Number of bytes to transfer
				dma_pd[pageind].next = (miobuf->nr_pages > 1) ? (int)(descP + 16*(pageind+1) + 0x1) : (int)0x7;		// if you add "+9" take care that dmadesc is either NO POINTER or char*
				length -= dma_pd[pageind].size;				
				}
			else {		
				dma_pd[pageind].src = localAddr;					// Local source address
				dma_pd[pageind].dest = (unsigned long) pci_map_page (0, map, 0, dma_pd[pageind].size, PCI_DMA_TODEVICE);
				dma_pd[pageind].size = (length > PAGE_SIZE) ? PAGE_SIZE : length;	// Number of bytes to transfer
				dma_pd[pageind].next = (length > PAGE_SIZE) ? (int)(descP + 16*(pageind+1) +  0x1 ): (int)0x7 ;	// if you add "+9" take care that dmadesc is either NO POINTER or char*
				length -= dma_pd[pageind].size;
				}
			
			// terminate if the page desc gets full !!	
			if(pageind >= DMA_DESC_SIZE/sizeof(DMAPLXPageDesc_T)) {
					dma_pd[pageind].next = 0x0f;
					if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec Page descriptor limit reached \n");
					return 0;
					}
					
			if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec dest 0x%x  size 0x%x \n",(unsigned int)dma_pd[pageind].dest,(unsigned int)dma_pd[pageind].size);
		} /* End of page loop */		
	} /* End of iovec loop */
	if(  length ) {
		printk("<1>Acqiris: dma_kiovec: remaining length !! 0x%x \n",length);
		for(pageind = 0; pageind < miobuf->nr_pages; pageind++)
			printk("<1>Acqiris: dma_kiovec: iob offset 0x%x iobuf size 0x%x size 0x%x next 0x%x\n",offset,miobuf->length,(unsigned int)dma_pd[pageind].size,(unsigned int)dma_pd[pageind].next);
		}
	
return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////
//	for writing data into the card via DMA
int dma_kiovec_w_fpga(ULONG *pAddr, char *descP, struct kiobuf *iovec[], unsigned long localAddr, AcqrsKMoDevExtension *dxP)
{
	int		err;
	int		length;
	int		i;
	int		pageind;
	int		offset;
	struct kiobuf *	miobuf = NULL;
	struct page *	map;
	DMAFPGAPageDesc_T  *dma_pd = (DMAFPGAPageDesc_T  *)pAddr; 

	/* since so far we have only one vector */
	int nr = 1;

	/* OK to walk down the iovec doing page IO on each page we find. */
    for (i = 0 ; i < nr ; ++i)
    {
		miobuf = iovec[i];
		offset = miobuf->offset;
		length = miobuf->length;
		miobuf->errno = 0;
		if (dbgl&DDMA) printk("<1>Acqiris: dma_kiovec # pages 0x%x  offset 0x%x length 0x%x \n",iobuf->nr_pages,miobuf->offset,miobuf->length);

        for (pageind = 0 ; pageind < miobuf->nr_pages ; ++pageind)
        {
			// The structure of a DMA descriptor block (consisting of 4 ULONGs) is described
			// in the PLX9080 manual in Fig. 3-17, p.32
			// The last four bits of the 'Next Descriptor Pointer' are:
			//	0x1 :	1 = PCI-address space (we don't use any local memory for descriptors)
			//	0x2 :	1 = end of chain, 0 = another descriptor follows
			//	0x4 :	1 = interrupt after terminal-count of this descriptor
			//	0x8 :	1 = read from local memory to PCI-bus, 0 = write to local memory

			map  = miobuf->maplist[pageind];

            if (!map)
            {
				err = -EFAULT;
				return 0;	// check ????
		   	}
						
            if(pageind == 0)
            {
				dma_pd[pageind].destLo = (unsigned long)pci_map_page(0, map, offset&~PAGE_OFFSET, dma_pd[pageind].size, PCI_DMA_TODEVICE);				
				dma_pd[pageind].destHi = 0;
				dma_pd[pageind].size = (PAGE_SIZE - (offset) > length) ? length : PAGE_SIZE - (offset); /* Number of bytes to transfer */
				dma_pd[pageind].next = (miobuf->nr_pages > 1) ? (int)(descP + 16*(pageind+1)) : (int)0x1;
				length -= dma_pd[pageind].size;				
			}
            else
            {		
				dma_pd[pageind].destLo = (unsigned long)pci_map_page(0, map, 0, dma_pd[pageind].size, PCI_DMA_TODEVICE);
				dma_pd[pageind].destHi = 0;
				dma_pd[pageind].size = (length > PAGE_SIZE) ? PAGE_SIZE : length; /* Number of bytes to transfer */
				dma_pd[pageind].next = (length > PAGE_SIZE) ? (int)(descP + 16*(pageind+1)): (int)0x1;
				length -= dma_pd[pageind].size;
			}
			
			// terminate if the page desc gets full !!	
            if (pageind >= DMA_DESC_SIZE / sizeof(DMAFPGAPageDesc_T))
            {
                dma_pd[pageind].next = 0x0f;
                if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec Page descriptor limit reached \n");
                return 0;
			}
					
			if(dbgl&DDMA) printk("<1>Acqiris: dma_kiovec dest 0x%x  size 0x%x \n",(unsigned int)dma_pd[pageind].destLo,(unsigned int)dma_pd[pageind].size);
        
        } /* End of page loop */		
    
    } /* End of iovec loop */
    
	// In the FPGA-implemented interface, we need to transfer the local address separately!
	if (dxP->deviceID != 0)
	{
		ULONG *dmaLocAddrP = (ULONG *)(dxP->res.controlBase + DMA0MODE_OFFSET + 0x8);
        WRITE_REGISTER_ULONG(dmaLocAddrP, localAddr);
        
	}

    if (length)
    {
		printk("<1>Acqiris: dma_kiovec: remaining length !! 0x%x \n",length);
		for(pageind = 0; pageind < miobuf->nr_pages; pageind++)
			printk("<1>Acqiris: dma_kiovec: iob offset 0x%x iobuf size 0x%x size 0x%x next 0x%x\n",offset,miobuf->length,(unsigned int)dma_pd[pageind].size,(unsigned int)dma_pd[pageind].next);
    
    }
	
    return 0;
}


